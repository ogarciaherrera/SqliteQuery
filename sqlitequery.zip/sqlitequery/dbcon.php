<?php

	$error = "X";
	$servername = "localhost";
	$username = "regadm01";
	$password = "regadm01";
	$database = "registro";
	$enlace = new mysqli($servername, $username, $password, $database);

?>